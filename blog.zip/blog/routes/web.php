<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// use Carbon;

Route::get('/', function () {
    // return view('first');


// echo Carbon::now();

$app_timezone = config('app.timezone');
	
$mytime = Carbon\Carbon::now();

echo $app_timezone;

echo '<h1> APP Time : ' .$app_timezone .'--'. $mytime->toDateTimeString();


$Timezones = new \Snscripts\Timezones\Timezones;

// $DateTime = $mytime ;

$DateTime = '2018-02-14 23:00:00';

$Timezone = '-05:00';

$format = 'Y-m-d H:i:s';

 

$local = $Timezones->convertToLocal($DateTime, $Timezone, $format);

echo '<h1>Local Time ' .$Timezone .'--'. $local ;
 

$india  =  $Timezones->convertToUTC($local, $Timezone, $format);

echo '<h1> <font color="green"> UTC Convert Time ' .$Timezone .'--'. $india.'</font> </h1>' ;


});

Route::get('/get_city', 'Controller@test');

