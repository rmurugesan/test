<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

       
		public function test(){

$user ="perpetualsolution56@gmail.com";
$password="9860777989";
 

$url ="http://pay.payonn.com/pg/PayGatewayServiceV3.asmx";

$input_xml = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <PaymentRequest xmlns="http://tempuri.org/">
      <req>
        <CustomerDC>
          <Name>string</Name>
          <Email>string</Email>
          <country_code>string</country_code>
          <Mobile>string</Mobile>
          <Gender>string</Gender>
          <DOB>string</DOB>
          <civil_id>string</civil_id>
          <Area>string</Area>
          <Block>string</Block>
          <Street>string</Street>
          <Avenue>string</Avenue>
          <Building>string</Building>
          <Floor>string</Floor>
          <Apartment>string</Apartment>
        </CustomerDC>
        <MerchantDC>
          <merchant_code>7449102297</merchant_code>
          <merchant_username>perpetualsolution56@gmail.com</merchant_username>
          <merchant_password>9860777989</merchant_password>
          <merchant_ReferenceID>string</merchant_ReferenceID>
          <ReturnURL>http://localhost:8000/return</ReturnURL>
          <merchant_error_url>http://localhost:8000/return</merchant_error_url> 
        </MerchantDC>
        <lstProductDC>
          <ProductDC>
            <product_name>taxi</product_name>
            <unitPrice>10</unitPrice>
            <qty>1</qty>
          </ProductDC> 
        </lstProductDC>
        <totalDC>
          <subtotal>10</subtotal>
        </totalDC>
        <paymentModeDC>
          <paymentMode>string</paymentMode>
        </paymentModeDC>
        <paymentCurrencyDC>
          <paymentCurrency>INR</paymentCurrency>
        </paymentCurrencyDC>
      </req>
    </PaymentRequest>
  </soap:Body>
</soap:Envelope>';
//echo($post_string);
//die();
        $soap_do     = curl_init();
       curl_setopt($soap_do, CURLOPT_URL, $url);
       curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 10);
       curl_setopt($soap_do, CURLOPT_TIMEOUT, 10);
       curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false);
       curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false);
       curl_setopt($soap_do, CURLOPT_POST, true);
       curl_setopt($soap_do, CURLOPT_POSTFIELDS, $input_xml);
       curl_setopt($soap_do, CURLOPT_HTTPHEADER, array(
           'Content-Type: text/xml; charset=utf-8',
           'Content-Length: ' . strlen($input_xml)
       ));
       curl_setopt($soap_do, CURLOPT_USERPWD, $user . ":" . $password);
       curl_setopt($soap_do, CURLOPT_HTTPHEADER, array(
           'Content-type: text/xml'
       ));
       
       $result = curl_exec($soap_do);
       
 		  print_r('<pre>');
        print_r($result);
        print_r('</pre>');


		}

       

}
