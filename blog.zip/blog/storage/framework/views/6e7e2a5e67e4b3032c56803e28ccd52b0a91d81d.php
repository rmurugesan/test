<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

  <?php






function curl($url){
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 30);
    curl_setopt($curl, CURLOPT_USERAGENT, 'cURL');
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($curl, CURLOPT_ENCODING , "gzip");//<< Solution

    $result = curl_exec($curl);
    curl_close($curl);

    return $result;
}


// $feed = curl("https://api.stackexchange.com/2.2/users/999/tags/php/top-answers?order=desc&sort=activity&site=stackoverflow");

// $feed = json_decode($feed,true);

// $rep = $feed['items'];

// var_dump($rep);//531776


// $feed = file_get_contents("https://api.stackexchange.com/2.2/users/999/tags/php/top-answers?order=desc&sort=activity&site=stackoverflow");


function get_url($url)
{
    //user agent is very necessary, otherwise some websites like google.com wont give zipped content
    $opts = array(
        'http'=>array(
            'method'=>"GET",
            'header'=>"Accept-Language: en-US,en;q=0.8rn" .
                        "Accept-Encoding: gzip,deflate,sdchrn" .
                        "Accept-Charset:UTF-8,*;q=0.5rn" .
                        "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:19.0) Gecko/20100101 Firefox/19.0 FirePHP/0.4rn"
        )
    );
 
    $context = stream_context_create($opts);
    $content = file_get_contents($url ,false,$context); 
     
    //If http response header mentions that content is gzipped, then uncompress it
    foreach($http_response_header as $c => $h)
    {
        if(stristr($h, 'content-encoding') and stristr($h, 'gzip'))
        {
            //Now lets uncompress the compressed data
            $content = gzinflate( substr($content,10,-8) );
        }
    }
     
    return $content;
}

$feed = "https://api.stackexchange.com/2.2/tags/php/top-answerers/all_time?site=stackoverflow";

$ff = get_url($feed);


$ff = json_decode($ff,true);

$rep = $ff['items'];

var_dump($rep);//531776



 


// var_dump($http_response_header);



   // echo '<pre>';
   // print_r($json_string); 
   // echo '</pre>';
    
  ?>
    </body>
</html>
